/****************************************************************************
** Meta object code from reading C++ file 'stepmanager.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../SIA/data/stepmanager.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'stepmanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSStepManagerENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSStepManagerENDCLASS = QtMocHelpers::stringData(
    "StepManager",
    "stepUpdateRequest",
    "",
    "stepCount",
    "emittedCurrentModules",
    "modules",
    "allStepsReadyToInstall",
    "allSteps",
    "terminate_app_request",
    "installationProgressAt20p",
    "installationProgressAt40p",
    "installationProgressAt60p",
    "installationProgressAt80p",
    "installationProgressAt100p",
    "fileRemoveError",
    "string",
    "uninstallFinished",
    "initModInstall",
    "setStep",
    "currentStep",
    "doNextStep",
    "doBackStep",
    "getStepToParse",
    "checkCurrentModules",
    "setInstallDir",
    "dir1",
    "dir2",
    "mod0",
    "mod1",
    "mod2",
    "initModUnpack",
    "initModRemove",
    "process_donate_button",
    "process_exit_button"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSStepManagerENDCLASS_t {
    uint offsetsAndSizes[68];
    char stringdata0[12];
    char stringdata1[18];
    char stringdata2[1];
    char stringdata3[10];
    char stringdata4[22];
    char stringdata5[8];
    char stringdata6[23];
    char stringdata7[9];
    char stringdata8[22];
    char stringdata9[26];
    char stringdata10[26];
    char stringdata11[26];
    char stringdata12[26];
    char stringdata13[27];
    char stringdata14[16];
    char stringdata15[7];
    char stringdata16[18];
    char stringdata17[15];
    char stringdata18[8];
    char stringdata19[12];
    char stringdata20[11];
    char stringdata21[11];
    char stringdata22[15];
    char stringdata23[20];
    char stringdata24[14];
    char stringdata25[5];
    char stringdata26[5];
    char stringdata27[5];
    char stringdata28[5];
    char stringdata29[5];
    char stringdata30[14];
    char stringdata31[14];
    char stringdata32[22];
    char stringdata33[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSStepManagerENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSStepManagerENDCLASS_t qt_meta_stringdata_CLASSStepManagerENDCLASS = {
    {
        QT_MOC_LITERAL(0, 11),  // "StepManager"
        QT_MOC_LITERAL(12, 17),  // "stepUpdateRequest"
        QT_MOC_LITERAL(30, 0),  // ""
        QT_MOC_LITERAL(31, 9),  // "stepCount"
        QT_MOC_LITERAL(41, 21),  // "emittedCurrentModules"
        QT_MOC_LITERAL(63, 7),  // "modules"
        QT_MOC_LITERAL(71, 22),  // "allStepsReadyToInstall"
        QT_MOC_LITERAL(94, 8),  // "allSteps"
        QT_MOC_LITERAL(103, 21),  // "terminate_app_request"
        QT_MOC_LITERAL(125, 25),  // "installationProgressAt20p"
        QT_MOC_LITERAL(151, 25),  // "installationProgressAt40p"
        QT_MOC_LITERAL(177, 25),  // "installationProgressAt60p"
        QT_MOC_LITERAL(203, 25),  // "installationProgressAt80p"
        QT_MOC_LITERAL(229, 26),  // "installationProgressAt100p"
        QT_MOC_LITERAL(256, 15),  // "fileRemoveError"
        QT_MOC_LITERAL(272, 6),  // "string"
        QT_MOC_LITERAL(279, 17),  // "uninstallFinished"
        QT_MOC_LITERAL(297, 14),  // "initModInstall"
        QT_MOC_LITERAL(312, 7),  // "setStep"
        QT_MOC_LITERAL(320, 11),  // "currentStep"
        QT_MOC_LITERAL(332, 10),  // "doNextStep"
        QT_MOC_LITERAL(343, 10),  // "doBackStep"
        QT_MOC_LITERAL(354, 14),  // "getStepToParse"
        QT_MOC_LITERAL(369, 19),  // "checkCurrentModules"
        QT_MOC_LITERAL(389, 13),  // "setInstallDir"
        QT_MOC_LITERAL(403, 4),  // "dir1"
        QT_MOC_LITERAL(408, 4),  // "dir2"
        QT_MOC_LITERAL(413, 4),  // "mod0"
        QT_MOC_LITERAL(418, 4),  // "mod1"
        QT_MOC_LITERAL(423, 4),  // "mod2"
        QT_MOC_LITERAL(428, 13),  // "initModUnpack"
        QT_MOC_LITERAL(442, 13),  // "initModRemove"
        QT_MOC_LITERAL(456, 21),  // "process_donate_button"
        QT_MOC_LITERAL(478, 19)   // "process_exit_button"
    },
    "StepManager",
    "stepUpdateRequest",
    "",
    "stepCount",
    "emittedCurrentModules",
    "modules",
    "allStepsReadyToInstall",
    "allSteps",
    "terminate_app_request",
    "installationProgressAt20p",
    "installationProgressAt40p",
    "installationProgressAt60p",
    "installationProgressAt80p",
    "installationProgressAt100p",
    "fileRemoveError",
    "string",
    "uninstallFinished",
    "initModInstall",
    "setStep",
    "currentStep",
    "doNextStep",
    "doBackStep",
    "getStepToParse",
    "checkCurrentModules",
    "setInstallDir",
    "dir1",
    "dir2",
    "mod0",
    "mod1",
    "mod2",
    "initModUnpack",
    "initModRemove",
    "process_donate_button",
    "process_exit_button"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSStepManagerENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      11,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  146,    2, 0x06,    1 /* Public */,
       4,    1,  149,    2, 0x06,    3 /* Public */,
       6,    1,  152,    2, 0x06,    5 /* Public */,
       8,    0,  155,    2, 0x06,    7 /* Public */,
       9,    0,  156,    2, 0x06,    8 /* Public */,
      10,    0,  157,    2, 0x06,    9 /* Public */,
      11,    0,  158,    2, 0x06,   10 /* Public */,
      12,    0,  159,    2, 0x06,   11 /* Public */,
      13,    0,  160,    2, 0x06,   12 /* Public */,
      14,    1,  161,    2, 0x06,   13 /* Public */,
      16,    0,  164,    2, 0x06,   15 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      17,    0,  165,    2, 0x0a,   16 /* Public */,
      18,    1,  166,    2, 0x0a,   17 /* Public */,
      20,    0,  169,    2, 0x0a,   19 /* Public */,
      21,    0,  170,    2, 0x0a,   20 /* Public */,
      22,    0,  171,    2, 0x0a,   21 /* Public */,
      23,    0,  172,    2, 0x0a,   22 /* Public */,
      24,    5,  173,    2, 0x0a,   23 /* Public */,
      30,    0,  184,    2, 0x0a,   29 /* Public */,
      31,    0,  185,    2, 0x0a,   30 /* Public */,
      32,    0,  186,    2, 0x0a,   31 /* Public */,
      33,    0,  187,    2, 0x0a,   32 /* Public */,

 // signals: parameters
    QMetaType::Int, QMetaType::Int,    3,
    QMetaType::QString, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::QString, QMetaType::QString,   15,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Int,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   25,   26,   27,   28,   29,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject StepManager::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSStepManagerENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSStepManagerENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSStepManagerENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<StepManager, std::true_type>,
        // method 'stepUpdateRequest'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'emittedCurrentModules'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'allStepsReadyToInstall'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'terminate_app_request'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'installationProgressAt20p'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'installationProgressAt40p'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'installationProgressAt60p'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'installationProgressAt80p'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'installationProgressAt100p'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'fileRemoveError'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'uninstallFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'initModInstall'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setStep'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'doNextStep'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'doBackStep'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'getStepToParse'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'checkCurrentModules'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setInstallDir'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'initModUnpack'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'initModRemove'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_donate_button'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_exit_button'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void StepManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<StepManager *>(_o);
        (void)_t;
        switch (_id) {
        case 0: { int _r = _t->stepUpdateRequest((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 1: { QString _r = _t->emittedCurrentModules((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 2: _t->allStepsReadyToInstall((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->terminate_app_request(); break;
        case 4: _t->installationProgressAt20p(); break;
        case 5: _t->installationProgressAt40p(); break;
        case 6: _t->installationProgressAt60p(); break;
        case 7: _t->installationProgressAt80p(); break;
        case 8: _t->installationProgressAt100p(); break;
        case 9: { QString _r = _t->fileRemoveError((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 10: _t->uninstallFinished(); break;
        case 11: _t->initModInstall(); break;
        case 12: _t->setStep((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 13: _t->doNextStep(); break;
        case 14: _t->doBackStep(); break;
        case 15: { int _r = _t->getStepToParse();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 16: _t->checkCurrentModules(); break;
        case 17: _t->setInstallDir((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[5]))); break;
        case 18: _t->initModUnpack(); break;
        case 19: _t->initModRemove(); break;
        case 20: _t->process_donate_button(); break;
        case 21: _t->process_exit_button(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = int (StepManager::*)(int );
            if (_t _q_method = &StepManager::stepUpdateRequest; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = QString (StepManager::*)(QString );
            if (_t _q_method = &StepManager::emittedCurrentModules; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (StepManager::*)(QString );
            if (_t _q_method = &StepManager::allStepsReadyToInstall; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (StepManager::*)();
            if (_t _q_method = &StepManager::terminate_app_request; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (StepManager::*)();
            if (_t _q_method = &StepManager::installationProgressAt20p; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (StepManager::*)();
            if (_t _q_method = &StepManager::installationProgressAt40p; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (StepManager::*)();
            if (_t _q_method = &StepManager::installationProgressAt60p; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (StepManager::*)();
            if (_t _q_method = &StepManager::installationProgressAt80p; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (StepManager::*)();
            if (_t _q_method = &StepManager::installationProgressAt100p; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 8;
                return;
            }
        }
        {
            using _t = QString (StepManager::*)(QString );
            if (_t _q_method = &StepManager::fileRemoveError; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (StepManager::*)();
            if (_t _q_method = &StepManager::uninstallFinished; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 10;
                return;
            }
        }
    }
}

const QMetaObject *StepManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *StepManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSStepManagerENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int StepManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
int StepManager::stepUpdateRequest(int _t1)
{
    int _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t0))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
    return _t0;
}

// SIGNAL 1
QString StepManager::emittedCurrentModules(QString _t1)
{
    QString _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t0))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
    return _t0;
}

// SIGNAL 2
void StepManager::allStepsReadyToInstall(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void StepManager::terminate_app_request()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void StepManager::installationProgressAt20p()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void StepManager::installationProgressAt40p()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void StepManager::installationProgressAt60p()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void StepManager::installationProgressAt80p()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void StepManager::installationProgressAt100p()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
QString StepManager::fileRemoveError(QString _t1)
{
    QString _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t0))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
    return _t0;
}

// SIGNAL 10
void StepManager::uninstallFinished()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}
QT_WARNING_POP
