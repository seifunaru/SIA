#include <QtQml/qqmlprivate.h>
#include <QtCore/qdir.h>
#include <QtCore/qurl.h>
#include <QtCore/qhash.h>
#include <QtCore/qstring.h>

namespace QmlCacheGeneratedCode {
namespace _qml_main_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_appControls_Button_solidSwap_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_appControls_LodImage_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_appControls_ParallaxImage_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_appControls_ProgressBarGradient_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_pageStyle_BasicIntroPage_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_pageStyle_Step_ConfirmInstallation_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_pageStyle_Step_ToggleMaker_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_themes_ThemeManager_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_appControls_SiaMessageBox_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_pageStyle_Step_ProgressBarInstall_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _qml_data_qml_pageStyle_Step_Credits_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _modFile_data_modFiles_ModfileInfoQml_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}

}
namespace {
struct Registry {
    Registry();
    ~Registry();
    QHash<QString, const QQmlPrivate::CachedQmlUnit*> resourcePathToCachedUnit;
    static const QQmlPrivate::CachedQmlUnit *lookupCachedUnit(const QUrl &url);
};

Q_GLOBAL_STATIC(Registry, unitRegistry)


Registry::Registry() {
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/main.qml"), &QmlCacheGeneratedCode::_qml_main_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/appControls/Button_solidSwap.qml"), &QmlCacheGeneratedCode::_qml_data_qml_appControls_Button_solidSwap_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/appControls/LodImage.qml"), &QmlCacheGeneratedCode::_qml_data_qml_appControls_LodImage_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/appControls/ParallaxImage.qml"), &QmlCacheGeneratedCode::_qml_data_qml_appControls_ParallaxImage_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/appControls/ProgressBarGradient.qml"), &QmlCacheGeneratedCode::_qml_data_qml_appControls_ProgressBarGradient_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/pageStyle/BasicIntroPage.qml"), &QmlCacheGeneratedCode::_qml_data_qml_pageStyle_BasicIntroPage_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/pageStyle/Step_ConfirmInstallation.qml"), &QmlCacheGeneratedCode::_qml_data_qml_pageStyle_Step_ConfirmInstallation_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/pageStyle/Step_ToggleMaker.qml"), &QmlCacheGeneratedCode::_qml_data_qml_pageStyle_Step_ToggleMaker_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/themes/ThemeManager.qml"), &QmlCacheGeneratedCode::_qml_data_qml_themes_ThemeManager_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/appControls/SiaMessageBox.qml"), &QmlCacheGeneratedCode::_qml_data_qml_appControls_SiaMessageBox_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/pageStyle/Step_ProgressBarInstall.qml"), &QmlCacheGeneratedCode::_qml_data_qml_pageStyle_Step_ProgressBarInstall_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/qml/data/qml/pageStyle/Step_Credits.qml"), &QmlCacheGeneratedCode::_qml_data_qml_pageStyle_Step_Credits_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/modFile/data/modFiles/ModfileInfoQml.qml"), &QmlCacheGeneratedCode::_modFile_data_modFiles_ModfileInfoQml_qml::unit);
    QQmlPrivate::RegisterQmlUnitCacheHook registration;
    registration.structVersion = 0;
    registration.lookupCachedQmlUnit = &lookupCachedUnit;
    QQmlPrivate::qmlregister(QQmlPrivate::QmlUnitCacheHookRegistration, &registration);
}

Registry::~Registry() {
    QQmlPrivate::qmlunregister(QQmlPrivate::QmlUnitCacheHookRegistration, quintptr(&lookupCachedUnit));
}

const QQmlPrivate::CachedQmlUnit *Registry::lookupCachedUnit(const QUrl &url) {
    if (url.scheme() != QLatin1String("qrc"))
        return nullptr;
    QString resourcePath = QDir::cleanPath(url.path());
    if (resourcePath.isEmpty())
        return nullptr;
    if (!resourcePath.startsWith(QLatin1Char('/')))
        resourcePath.prepend(QLatin1Char('/'));
    return unitRegistry()->resourcePathToCachedUnit.value(resourcePath, nullptr);
}
}
int QT_MANGLE_NAMESPACE(qInitResources_resources)() {
    ::unitRegistry();
    Q_INIT_RESOURCE(resources_qmlcache);
    return 1;
}
Q_CONSTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qInitResources_resources))
int QT_MANGLE_NAMESPACE(qCleanupResources_resources)() {
    Q_CLEANUP_RESOURCE(resources_qmlcache);
    return 1;
}
