/****************************************************************************
** Meta object code from reading C++ file 'custommodfunctions.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../SIA/data/custommodfunctions.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'custommodfunctions.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSCustomModFunctionsENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSCustomModFunctionsENDCLASS = QtMocHelpers::stringData(
    "CustomModFunctions",
    "request_init_modInstallation",
    "",
    "mod_install_dir_1_isOk",
    "state",
    "mod_install_dir_2_isOk",
    "mod_uninstall_dir_1_isOk",
    "mod_uninstall_dir_2_isOk",
    "emittedInstallDirs",
    "dir1",
    "dir2",
    "checkModInstallDir1",
    "userInput",
    "checkModInstallDir2",
    "checkModUninstallDir1",
    "checkModUninstallDir2",
    "getInstallDirs"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSCustomModFunctionsENDCLASS_t {
    uint offsetsAndSizes[34];
    char stringdata0[19];
    char stringdata1[29];
    char stringdata2[1];
    char stringdata3[23];
    char stringdata4[6];
    char stringdata5[23];
    char stringdata6[25];
    char stringdata7[25];
    char stringdata8[19];
    char stringdata9[5];
    char stringdata10[5];
    char stringdata11[20];
    char stringdata12[10];
    char stringdata13[20];
    char stringdata14[22];
    char stringdata15[22];
    char stringdata16[15];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSCustomModFunctionsENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSCustomModFunctionsENDCLASS_t qt_meta_stringdata_CLASSCustomModFunctionsENDCLASS = {
    {
        QT_MOC_LITERAL(0, 18),  // "CustomModFunctions"
        QT_MOC_LITERAL(19, 28),  // "request_init_modInstallation"
        QT_MOC_LITERAL(48, 0),  // ""
        QT_MOC_LITERAL(49, 22),  // "mod_install_dir_1_isOk"
        QT_MOC_LITERAL(72, 5),  // "state"
        QT_MOC_LITERAL(78, 22),  // "mod_install_dir_2_isOk"
        QT_MOC_LITERAL(101, 24),  // "mod_uninstall_dir_1_isOk"
        QT_MOC_LITERAL(126, 24),  // "mod_uninstall_dir_2_isOk"
        QT_MOC_LITERAL(151, 18),  // "emittedInstallDirs"
        QT_MOC_LITERAL(170, 4),  // "dir1"
        QT_MOC_LITERAL(175, 4),  // "dir2"
        QT_MOC_LITERAL(180, 19),  // "checkModInstallDir1"
        QT_MOC_LITERAL(200, 9),  // "userInput"
        QT_MOC_LITERAL(210, 19),  // "checkModInstallDir2"
        QT_MOC_LITERAL(230, 21),  // "checkModUninstallDir1"
        QT_MOC_LITERAL(252, 21),  // "checkModUninstallDir2"
        QT_MOC_LITERAL(274, 14)   // "getInstallDirs"
    },
    "CustomModFunctions",
    "request_init_modInstallation",
    "",
    "mod_install_dir_1_isOk",
    "state",
    "mod_install_dir_2_isOk",
    "mod_uninstall_dir_1_isOk",
    "mod_uninstall_dir_2_isOk",
    "emittedInstallDirs",
    "dir1",
    "dir2",
    "checkModInstallDir1",
    "userInput",
    "checkModInstallDir2",
    "checkModUninstallDir1",
    "checkModUninstallDir2",
    "getInstallDirs"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSCustomModFunctionsENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   80,    2, 0x06,    1 /* Public */,
       3,    1,   81,    2, 0x06,    2 /* Public */,
       5,    1,   84,    2, 0x06,    4 /* Public */,
       6,    1,   87,    2, 0x06,    6 /* Public */,
       7,    1,   90,    2, 0x06,    8 /* Public */,
       8,    2,   93,    2, 0x06,   10 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      11,    1,   98,    2, 0x0a,   13 /* Public */,
      13,    1,  101,    2, 0x0a,   15 /* Public */,
      14,    1,  104,    2, 0x0a,   17 /* Public */,
      15,    1,  107,    2, 0x0a,   19 /* Public */,
      16,    0,  110,    2, 0x0a,   21 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Bool, QMetaType::Bool,    4,
    QMetaType::Bool, QMetaType::Bool,    4,
    QMetaType::Bool, QMetaType::Bool,    4,
    QMetaType::Bool, QMetaType::Bool,    4,
    QMetaType::QString, QMetaType::QString, QMetaType::QString,    9,   10,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject CustomModFunctions::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSCustomModFunctionsENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSCustomModFunctionsENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSCustomModFunctionsENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<CustomModFunctions, std::true_type>,
        // method 'request_init_modInstallation'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'mod_install_dir_1_isOk'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'mod_install_dir_2_isOk'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'mod_uninstall_dir_1_isOk'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'mod_uninstall_dir_2_isOk'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'emittedInstallDirs'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'checkModInstallDir1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'checkModInstallDir2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'checkModUninstallDir1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'checkModUninstallDir2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'getInstallDirs'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void CustomModFunctions::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CustomModFunctions *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->request_init_modInstallation(); break;
        case 1: { bool _r = _t->mod_install_dir_1_isOk((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 2: { bool _r = _t->mod_install_dir_2_isOk((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 3: { bool _r = _t->mod_uninstall_dir_1_isOk((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 4: { bool _r = _t->mod_uninstall_dir_2_isOk((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 5: { QString _r = _t->emittedInstallDirs((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 6: _t->checkModInstallDir1((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->checkModInstallDir2((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->checkModUninstallDir1((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 9: _t->checkModUninstallDir2((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 10: _t->getInstallDirs(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (CustomModFunctions::*)();
            if (_t _q_method = &CustomModFunctions::request_init_modInstallation; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = bool (CustomModFunctions::*)(bool );
            if (_t _q_method = &CustomModFunctions::mod_install_dir_1_isOk; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = bool (CustomModFunctions::*)(bool );
            if (_t _q_method = &CustomModFunctions::mod_install_dir_2_isOk; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = bool (CustomModFunctions::*)(bool );
            if (_t _q_method = &CustomModFunctions::mod_uninstall_dir_1_isOk; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = bool (CustomModFunctions::*)(bool );
            if (_t _q_method = &CustomModFunctions::mod_uninstall_dir_2_isOk; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = QString (CustomModFunctions::*)(QString , QString );
            if (_t _q_method = &CustomModFunctions::emittedInstallDirs; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    }
}

const QMetaObject *CustomModFunctions::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CustomModFunctions::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSCustomModFunctionsENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int CustomModFunctions::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void CustomModFunctions::request_init_modInstallation()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
bool CustomModFunctions::mod_install_dir_1_isOk(bool _t1)
{
    bool _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t0))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
    return _t0;
}

// SIGNAL 2
bool CustomModFunctions::mod_install_dir_2_isOk(bool _t1)
{
    bool _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t0))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
    return _t0;
}

// SIGNAL 3
bool CustomModFunctions::mod_uninstall_dir_1_isOk(bool _t1)
{
    bool _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t0))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
    return _t0;
}

// SIGNAL 4
bool CustomModFunctions::mod_uninstall_dir_2_isOk(bool _t1)
{
    bool _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t0))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
    return _t0;
}

// SIGNAL 5
QString CustomModFunctions::emittedInstallDirs(QString _t1, QString _t2)
{
    QString _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t0))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
    return _t0;
}
QT_WARNING_POP
